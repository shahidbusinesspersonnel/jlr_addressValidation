import sys
# import json
import math
import datefinder
from datetime import datetime


def fetchRegNo(input_text):
    # print('input_text', input_text)
    reg_no = input_text.split("Registration")[1]
    return reg_no


def fetcCompanyName(input_text):
    return input_text


def fetchAddress(input_text):
    # for name in input_text
    return input_text

def fetchDateofRegistration(input_text):
    date_of_first_reg = ""
    for text in input_text:
        # print('text=', text)
        matches = datefinder.find_dates(text)
        # print('matches=', matches)
        for match in matches:
            date_of_first_reg = match
            if date_of_first_reg is not None:
                date_of_first_reg = match.strftime("%m/%d/%Y")
                break
        if date_of_first_reg is not None:
            break
    return date_of_first_reg

def extractResultsfromOCRTextx(input):
    counter = 0
    text_lists = input.split("\n")
    # text_lists = input.split("\n")
    # print(text_lists)
    result = {}
    index = 0
    isRegSet = False
    for text in text_lists:
        index = index + 1
        if "Registration" in text and isRegSet == False and any(map(str.isdigit, text)):
            result["registrationNumber"] = fetchRegNo(text)
            isRegSet = True
        if "c.1.1" in  text.lower() or "С.1.1" in text:
            result["company_name"] = fetcCompanyName(text_lists[index-2])
        if "Frame No" in text:
            result["vin_no"] = fetchAddress(text_lists[index])
        if "Date of first registration" in text:
            # print('text 127', text_lists[index :index+ 2])
            result["date_of_fist_registration"] = fetchDateofRegistration(text_lists[index :index + 2 ])
    return result

if __name__ == "__main__":
    # texts = json.loads(sys.argv[1])
    # texts = sys.argv[1]
    # print('texts', texts)
    
    # print('extractedResult=', extractedResult)
    # texts = """ELV.
    # 01/19.
    # UK Registration Certificate
    # Official use only
    # Registered keeper any deti tro wiong enber the comict det
    # in section 6. sign section 8, and retum to OVLA
    # V5C3
    # 4.
    # Vehicle details
    # 5.
    # C.4.c- This document is not proof of ownership.
    # Registration V F 17 FBC
    # 2 A.1] Validation
    # character
    # 3
    # С.1.1
    # JAGUAR LAND ROVER LIMITED
    # number
    # 041051
    # C.1.3 BUILDING 548
    # BANBURY ROAD
    # GAYDON
    # WARWICK
    # CV35 ORR
    # B
    # Date of first registration
    # 28 07 2017
    # [B.1] Date of first registration in the UK
    # 28 07 2017
    # D.1 Make
    # JAGUAR
    # D.2 Type
    # Name
    # Busin
    # Please write in black ink and CAPITAL LETTERS.
    # New keeper or new name/new address details
    # Please see section 12
    # Variant
    # Addre
    # 6.
    # Version
    # Please tick Z the
    # appropriate box
    # Mr 1 Mrs 2 Miss 3
    # 4.
    # Post
    # Title (for example, Ms, Rev
    # and so on) or business name:
    # D.3 Model
    # Post
    # D.5 Body type
    # 4 DOOR SALOON
    # First names:
    # (X) Taxation class
    # PRIVATE/LIGHT GOODS (PLG)
    # Surname:
    # [D.6] Suspension Type
    # For company use only
    # DVLA/DVA Fleet number
    # Date of birth (not required by law)
    # M Revenue weight
    # Please help us to help you
    # by giving your postcode.
    # Postcode:
    # P.1 Cylinder capacity (cc)
    # 5000 CC
    # DD MM
    # 9.
    # V.7 CO2 (g/km)
    # P.3 Type of fuel
    # PETROL
    # na
    # House No:
    # S.1 Number of seats, including driver 5
    # Address:
    # S.2 Number of standing places
    # (where appropriate)
    # 10
    # [D.4] Wheelplan
    # 2-AXLE-RIGID BODY
    # 11
    # Post town:
    # Vehicle category
    # New keeper?
    # If so tick this box:
    # J
    # Date of sale
    # к 12
    # or transfer: 1MIMYY 13
    # K
    # Type approval number
    # PROTOTYPE
    # Driving licence number of the
    # new keeper (not required by law)
    # Present mileage
    # (not required by law)
    # P.2 Max. net power (kW)
    # VIN/Chassis/Frame No.
    # SAJAA4BX2JCP14961
    # 15
    # P.5 Engine number
    # 17022851022
    # R
    # 16
    # S 17
    # F.1
    # Max. permissible mass (exc. m/c)
    # G
    # Mass in service
    # 1725
    # 7.
    # Only enter corrected
    # Changes to current vehicle or altered details
    # H 19
    # Power/Weight ratio (kW/kg)
    # (only for motorcycles)
    # Wheelplan / Body type
    # R
    # Colour
    # WHITE
    # 20
    # VIN / Chassis / Frame Number
    # Technical permissible maximum
    # towable mass of the trailer:
    # 21
    # Cylinder capacity (cc)
    # 0.1 braked (kg)
    # New revenue weight
    # Date of change
    # 0.2 unbraked (kg)
    # 22
    # 23
    # 24
    # Sound level:
    # No, of seats
    # inc. driver
    # No. of standing
    # places
    # U.1 stationary (dB(A)
    # Type of fuel
    # U.2 engine speed (min-1)
    # 25
    # 26
    # 27
    # U.3 drive-by (dB(A))
    # Engine number
    # V
    # Exhaust Emissions:
    # 28
    # CLR
    # V.1 CO (g/km or g/kWh)
    # New colour
    # Date of change
    # V.2 HC (g/km or g/kWh)
    # 29
    # 30
    # Tax class*
    # V.3 NOx (g/km or g/kWh)
    # V.4 HC+NOx (g/km)
    # Y 31
    # 32
    # "The tax class shown in section 4 can only be changed when taxing.
    # Please apply at your nearest Post Office.
    # V.5 particulates (g/km or g/kWh)
    # Declaration - You MUST sign, date and return this page to DVLA, Swansea, SA99 1BA when you notify any changes.
    # Registered keeper: I declare that the new details I have given are correct to the New keeper: I declare that this vehicle was sold or transferred to me on the
    # best of my knowledge."""
    print("hello")
    # extractedResult = extractResultsfromOCRTextx(texts)
    # print(json.dumps(extractedResult))
    