module.exports = {
    "Prediction_key": 'a1d86685b01e478298a67a35e0cf9b72',
    "col_dir":'C:/Learning/Python/Exercises/Meter Reading',
    "Server":'eastus.api.cognitive.microsoft.com',
    "URL": "https://eastus.api.cognitive.microsoft.com/customvision/v3.0/Prediction/edfef963-2f8d-4025-9f3d-0264962bfbf4/classify/iterations/NewModelC/image?%s",
    "URLCC" :" https://automl.googleapis.com/v1beta1/projects/1041443654570/locations/us-central1/models/ICN6399705230446952448:predict",
    "Map_file": "Mapping.json",
    'SOURCE_IMAGE_PATH':'',
    'DESTINATION_IMAGE_PATH':"",
    "project_id": "569635879842",
    "computeRegion":"us-central1",
    "CMI":"ICN1366228959418646528",
    "CCMI":"ICN5434386797817757696",
    "project_id_ccw":"569635879842"
}
