let s3onfig = {
    secretAccessKey : 'TW/HkmPEMhUwNY0t+dphWtJIFIJnojTmYJBcWYQR',
    accessKeyId : 'AKIAIDT2ISJ5VDTAYF7Q',
    region : 'ap-south-1'
};

module.exports = s3onfig;