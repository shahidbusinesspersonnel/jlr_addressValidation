let path = require('path');
var logger = require('logger').createLogger();
var check = require(path.join(__dirname, '..', 'service', 'util', 'checkValidObject'));
var gpsService = require(path.join(__dirname, '..', 'service', 'util', 'gpsService'));
var requestData = require('request');
let config = require(path.join(__dirname, '..', 'configs', 'appConfig'));
var async = require('async');
var similarityCheckService = require(path.join(__dirname, '..', 'service', 'util', 'findStringSimilarity'));
var parsingService = require(path.join(__dirname, '..', 'service', 'util', 'parsingService'));


exports.addressValidator = function (req, res) {
	let validateCompanyPresence_resp = {};
	try {
		console.log("Request input=", req.body);

		let raw_sourceAddress = req.body.sourceAddress;
		let raw_destAddress = req.body.destAddress;
		//Get the source address standardized using Google Service

		let sourceAddress = {};
		let destinationAddress = {};
		sourceAddress.zipCode = raw_sourceAddress["source_zip"];;
		sourceAddress.Address_Ln_1 = raw_sourceAddress["Address_Ln_1"];
		sourceAddress.Country = raw_sourceAddress["source_Country"];

		destinationAddress.zipCode = raw_destAddress["dest_zip"];
		destinationAddress.Address_Ln_1 = raw_destAddress["dest_Address_Ln_1"];
		destinationAddress.Country = raw_destAddress["dest_Country"];
		console.log('Input Source Address=', sourceAddress );
		gpsService.getFormattedAddress(sourceAddress, function (result_FormattedSource) {
			console.log('result_FormattedSource', result_FormattedSource);
			if (result_FormattedSource['status'] == 'SUCCESS') {
				console.log('Input Destination Address=', destinationAddress );
				gpsService.getFormattedAddress(destinationAddress, function (result_FormattedDest) {
					console.log('result_FormattedDest=', result_FormattedDest);
					if (result_FormattedDest['status'] == 'SUCCESS') {
						//Get comparisn scrore agaist standardize addresses
						similarityCheckService.findSimilarityBetweeString(result_FormattedSource.formattedAddress, result_FormattedDest.formattedAddress, function (result) {
							if (result["status"] == "SUCCESS") {
								validateCompanyPresence_resp.status = 'SUCCESS';
								validateCompanyPresence_resp.ADDRESS_STD_STATUS = 'SUCCESS';
								validateCompanyPresence_resp.standard_source_addr = result_FormattedSource;
								validateCompanyPresence_resp.standard_dest_addr = result_FormattedDest;
								validateCompanyPresence_resp.comparisn_result = result['data'];
								res.status = 200;
								res.send(validateCompanyPresence_resp);
							}
							else {
								//Get comparisn scrore agaist NON-standardize addresses
								similarityCheckService.findSimilarityBetweeString(sourceAddress.Address_Ln_1, destinationAddress.dest_Address_Ln_1, function (result) {
									if (result["status"] == "SUCCESS") {
										validateCompanyPresence_resp.status = 'SUCCESS';
										validateCompanyPresence_resp.ADDRESS_STD_STATUS = 'FAILED';
										validateCompanyPresence_resp.comparisn_result = result['data'];
										res.status = 200;
										res.send(validateCompanyPresence_resp);
									}
									else {
										validateCompanyPresence_resp.status = 'ERROR';
										validateCompanyPresence_resp.ADDRESS_STD_STATUS = 'FAILED';
										res.status = 500;
										res.send(validateCompanyPresence_resp);
									}

								});
							}
						});
					}
					else {
						//Get comparisn scrore agaist NON-standardize addresses
						similarityCheckService.findSimilarityBetweeString(sourceAddress.Address_Ln_1, destinationAddress.dest_Address_Ln_1, function (result) {
							if (result["status"] == "SUCCESS") {
								validateCompanyPresence_resp.status = 'SUCCESS';
								validateCompanyPresence_resp.ADDRESS_STD_STATUS = 'FAILED';
								validateCompanyPresence_resp.comparisn_result = result['data'];
								res.send(validateCompanyPresence_resp);
							}
							else {
								validateCompanyPresence_resp.status = 'ERROR';
								validateCompanyPresence_resp.ADDRESS_STD_STATUS = 'FAILED';
								res.send(validateCompanyPresence_resp);
							}

						});
					}
				});
			}
			else {
				//Get comparisn scrore agaist NON-standardize addresses
				similarityCheckService.findSimilarityBetweeString(sourceAddress.Address_Ln_1, destinationAddress.dest_Address_Ln_1, function (result) {
					if (result["status"] == "SUCCESS") {
						validateCompanyPresence_resp.status = 'SUCCESS';
						validateCompanyPresence_resp.ADDRESS_STD_STATUS = 'FAILED';
						validateCompanyPresence_resp.comparisn_result = result['data'];
						res.status = 200;
						res.send(validateCompanyPresence_resp);
					}
					else {
						validateCompanyPresence_resp.status = 'ERROR';
						validateCompanyPresence_resp.ADDRESS_STD_STATUS = 'FAILED';
						res.status = 500;
						res.send(validateCompanyPresence_resp);
					}

				});
			}
		});

	} catch (error) {
		validateCompanyPresence_resp.status = 'ERROR';
		validateCompanyPresence_resp.data = 'Internal Server Error !!'
		res.send(validateCompanyPresence_resp);
		console.log('Error', error);
	}
}
