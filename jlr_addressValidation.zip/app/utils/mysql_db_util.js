var path = require('path');
let mysqlConnection = require(path.join(__dirname, '..', 'database', 'mysqlConnection'));
let errorcodes        = require(path.join(__dirname, '..', 'errorcodes')); 

let mySqlDbConnection = {};


mySqlDbConnection.executeQueryData = function(querystring,result,callback){
  mysqlConnection.createConnection(function (error, connection) {
    if (error) {
      console.log("error = " + error);
      result.errorCode = errorcodes.UNABLE_TO_CONNECT_TO_DATABASE;
    }
    else {
      connection.query(querystring, function (error, resultset) {
        console.log('querystring=', querystring);
        if (error) {
          result.errorCode = errorcodes.SQL_ERROR;
          connection.rollback(function() {
            // throw error;
            console.log("error = " + error);
          });
        }
        else {
          result.data = resultset;
          callback(resultset)
        }
      });
    }
  });
}

module.exports = mySqlDbConnection;
