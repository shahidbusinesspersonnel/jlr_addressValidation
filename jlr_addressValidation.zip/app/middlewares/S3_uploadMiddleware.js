const multer = require('multer');
var multerS3 = require('multer-s3');
var path = require('path');
let s3 = require('../../database/s3Connect.js');
let helpers = require('../../utils/helpers.js');

var upload = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'ocr-meter-images',
        key: function (req, file, cb) {
            console.log("sassa", file);
            cb(null, "OCR/" + file.fieldname + '_' + Date.now() + path.extname(file.originalname));
        }
    }),
    fileFilter: helpers.imageFilter
});

module.exports = upload;



