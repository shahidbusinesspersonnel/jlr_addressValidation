var path = require('path');
var stringSimilarity = require("string-similarity");
var check = require(path.join(__dirname, 'checkValidObject'));

exports.findSimilarityBetweeString = function(input_1, input_2, callback){
    // console.log('input_1, input_2', input_1, input_2);
    let findSimilarityBetweeString_resp = {};
    try {
        if(!check.isUndefinedOrNullOrEmptyOrNoLen(input_1) && !check.isUndefinedOrNullOrEmptyOrNoLen(input_2)){
            var similarity = stringSimilarity.compareTwoStrings(input_1, input_2);
            console.log('similarity',similarity);
            let result = {};
            findSimilarityBetweeString_resp.status = 'SUCCESS';
            result.SOURCE_ADDRESS = input_1;
            result.TARGET_ADDRESS = input_2;
            result.MATCH_SCORE = similarity;
            findSimilarityBetweeString_resp.data = result;
            callback(findSimilarityBetweeString_resp);
        }
        else{
            findSimilarityBetweeString_resp.status = 'ERROR';
            findSimilarityBetweeString_resp.data = 'Invalid input';
            callback(findSimilarityBetweeString_resp)
        }

    } catch (error) {
        findSimilarityBetweeString_resp.status = 'ERROR';
        console.log('Error in Find Similarity', error);
        callback(findSimilarityBetweeString_resp)
    }
}