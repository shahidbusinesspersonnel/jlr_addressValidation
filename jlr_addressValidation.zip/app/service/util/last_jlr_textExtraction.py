import sys
import json
import math
import datefinder
from datetime import datetime


def fetchRegNo(input_text):
    # print('input_text', input_text)
    reg_no = input_text.split("Registration")[1]
    return reg_no


def fetcCompanyName(input_text):
    return input_text


def fetchAddress(input_text):
    return input_text

def fetchDateofRegistration(input_text):
    date_of_first_reg = ""
    for text in input_text:
        # print('text=', text)
        matches = datefinder.find_dates(text)
        # print('matches=', matches)
        for match in matches:
            date_of_first_reg = match
            if date_of_first_reg is not None:
                date_of_first_reg = match.strftime("%m/%d/%Y")
                break
        if date_of_first_reg is not None:
            break
    return date_of_first_reg

def extractResultsfromOCRTextx(input):
    counter = 0
    text_lists = input.split("\n")
    # text_lists = input.split("\n")
    # print(text_lists)
    result = {}
    index = 0
    isRegSet = False
    for text in text_lists:
        index = index + 1
        if "Registration" in text and isRegSet == False and any(map(str.isdigit, text)):
            result["registrationNumber"] = fetchRegNo(text)
            isRegSet = True
	if "С.1.1" in text:
            result["company_name"] = fetcCompanyName(text_lists[index])
        if "Frame No" in text:
            result["vin_no"] = fetchAddress(text_lists[index])
        if "Date of first registration" in text:
            # print('text 127', text_lists[index :index+ 2])
            result["date_of_fist_registration"] = fetchDateofRegistration(text_lists[index :index + 2 ])
    return result

if __name__ == "__main__":
    #texts = json.loads(sys.argv[1])
    texts = sys.argv[1]
    extractedResult = extractResultsfromOCRTextx(texts)
    # print('extractedResult=', extractedResult)
    print(extractedResult)
    
