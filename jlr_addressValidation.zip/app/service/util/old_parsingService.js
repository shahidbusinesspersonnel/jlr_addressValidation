let path = require('path');
var check = require(path.join(__dirname, 'checkValidObject'));
const dateFinder = require('datefinder');
const { promisify } = require('util');
const sleep = promisify(setTimeout);

exports.extractandPrepareReaminingData = function(input, callback){
    let extractandPrepareReaminingData_resp = {};
    try {
        // console.log('inp', input);
        let input_list = input.split("\n");
        let lineCounter = 0;
        input_list.forEach(line=>{
            lineCounter = lineCounter + 1;
            let stringLine = line.toString();
            if(stringLine.includes('Registration') &&  stringLine.match(/\d+/g)){
                extractandPrepareReaminingData_resp.registrationNumber = getRegistrationNumber(line);
            }
            if(line.includes('c.1.1') || line.includes('С.1.1') || line.includes('C.1.1') || line.includes('C.1,1') ){
                console.log('line=', line);
                extractandPrepareReaminingData_resp.name = getCompanyName(input_list.slice(lineCounter -2, lineCounter +1));
            }

            if(stringLine.includes("Date of first registration") || line.includes("Date of first registration")){
                console.log('Date of first registration', stringLine);
                extractandPrepareReaminingData_resp.date_of_first_registration = getDateOfFirstRegistration(input_list.slice(lineCounter -1, lineCounter + 2));
            }
            if(stringLine.includes("Frame No")){
                extractandPrepareReaminingData_resp.vin_no = getVinNumber(input_list.slice(lineCounter -2, lineCounter +1));
                
            }
        });
        console.log('extractandPrepareReaminingData_resp', extractandPrepareReaminingData_resp)
        sleep(500).then(() => {
            extractandPrepareReaminingData_resp.status ='SUCCESS';
            callback(extractandPrepareReaminingData_resp);
        });
    } catch (error) {
        console.log('error', error)
    }
}

function getRegistrationNumber(input){
    return input.split("Registration")[1];
}

function getCompanyName(input){
    console.log('getCompanyName', input);
    var longest = input.sort(
    function (a, b) {
        return b.length - a.length;
    }
)[0];
    console.log('longest', longest);
    return longest;
}

function getDateOfFirstRegistration(input){
    console.log('input 82' , input);
    let dateofReg = "";
    for (let i =0; i<input.length; i++){
        let spaceFreeLine = input[i].replace(/\D/g,'');
        console.log('spaceFreeLine', spaceFreeLine);
        if(/^\d+$/.test(spaceFreeLine) && spaceFreeLine.length == 8  ){
            console.log('89', input[i]);
            dateofReg = input[i];
            return dateofReg;
        }
    }
}

function getVinNumber(input){
    let vin_no = "";
    for (let i = 0; i < input.length; i ++ ){
        if(input[i].length == 17 ){
            vin_no = input[i];
            break;
        }
    }
    return vin_no;
    console.log('83=', input);
}
