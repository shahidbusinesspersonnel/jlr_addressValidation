let path = require('path');
var check = require(path.join(__dirname, 'checkValidObject'));
const dateFinder = require('datefinder');
const { promisify } = require('util');
const { call } = require('@google-cloud/vision/build/src/helpers');
const sleep = promisify(setTimeout);
// const dateFinder = require('datefinder')


// exports.fetchRegistrationNumber = function (input, callback) {
//     try {
//         let reg_str = input.replace("/[^a-zA-Z0-9/\n]/g", "");
//         console.log('reg_str', reg_str);
//         let reg_str_list = reg_str.split('\n');
//         let final_string = "";
//         for(i =0; i<reg_str_list.length; i++){
//             console.log('reg_str_list.length', reg_str_list.length, reg_str_list[i])
//             if(reg_str_list[0].length == 7){
//                 final_string = reg_str_list[i];
//                 break;
//             }
//         }
//         if(final_string.length == 7){
//             formulateFinalReg(final_string, function(result){
//                 callback(result);
//             });
//         }
//         else{
//             let reg_str_next = input.replace("/[^a-zA-Z0-9/]/g", "");
//             if(/^\d+$/.test(reg_str_next.charAt(reg_str_next.length -1))){
//                 let reg_no = reg_str_next.substring(0, reg_str_next.length -1 )
//                 formulateFinalReg(reg_no, function(result){
//                     callback(result);
//                 });
//             }
//             else if(/^\d+$/.test(reg_str_next.charAt(0))){
//                 let reg_no = reg_str_next.substring(1, reg_str_next.length);
//                 formulateFinalReg(reg_no, function(result){
//                     callback(result);
//                 });  
//             }
//         }
        
//     } catch (error) {
        
//     }
// }

exports.fetchRegistrationNumber = function (input, callback) {
    try {
        console.log(input);
        let reg_no = input.replace(" ", "").replace('\n', "");
        let final_string = reg_no;
        console.log('13',reg_no, reg_no.charAt(reg_no.length -1), reg_no.charAt(0) , reg_no.length);
        if (reg_no.length == 7){
            if( reg_no.charAt(0) == '0' || reg_no.charAt(reg_no.length -1) == '0' ){
                if(reg_no.charAt(0) == '0'){
                    let part_string = reg_no.substring(1);
                    final_string = 'O' + part_string;
                }
                if(reg_no.charAt(reg_no.length -1) == '0'){
                    let part_string = reg_no.substring(-1);
                    final_string = part_string + 'O';
                }
                formulateFinalReg(final_string, function(result){
                    callback(result);
                });
                
            }
            else{
                formulateFinalReg(reg_no, function(result){
                    callback(result);
                });
                // callback(reg_no);
            }
        }
        else if(reg_no.length > 7){
            let final_string = "";
            if(  /^\d+$/.test(reg_no.charAt(0))){
                let part_string = reg_no.substring(1);
                if(part_string.length == 7){
                    formulateFinalReg(part_string, function(result){
                        callback(result);
                    });
                    // callback(part_string);
                }
            }
            if(  /^\d+$/.test(reg_no.charAt(reg_no.length -1)) ){
                let part_string = reg_no.substring(0, reg_no.length -1);
                if(part_string.length == 7){
                    formulateFinalReg(part_string, function(result){
                        callback(result);
                    });
                    // callback(part_string);
                }
            }
            if(  /^\d+$/.test(reg_no.charAt(0))  || /^\d+$/.test(reg_no.charAt(reg_no.length -1)) ){
                let part_string = reg_no.substring(1,reg_no.length -1);
                formulateFinalReg(part_string, function(result){
                    callback(result);
                });
                // callback(part_string);
            }
            else{
                formulateFinalReg(reg_no, function(result){
                    callback(result);
                });
                // callback(reg_no);
            }
        }
        else{
            callback(reg_no);
        }
        // callback();
    } catch (error) {
        console.log('error', error);
    }   
}

function formulateFinalReg(input, callback){
    console.log('82', input)
    let reg_str = input.replace("/[^a-zA-Z0-9/]/g", "");
    console.log('85', reg_str)
    let final_reg_string = reg_str.substring(0,4) + " " + reg_str.substring(input.length-3);
    console.log(reg_str.substring(-3));
    callback(final_reg_string);
}

exports.fetchName = function (input, callback) {
    try {
        console.log('temp_Name=', input);
        let temp_Name_list = input.split('\n');
        if(temp_Name_list[0].includes('This')){
            let name = temp_Name_list.slice(1);
            let sub_list = name.toString().split(" ");
            if(sub_list[0].length == 1){
                callback(name.toString().substring(1).replace(",", " "));
            }
            else{
                callback(name.toString().replace(",", " "));
            }
        }
        else{
            console.log('33=', input);
            let temp_name = input.split(" ");
            if(temp_name[0].length == 1){
                let finaleName = input.substring(1).replace(/\n/g, " ").replace(/[^A-Z0-9 ]/g, "");
                callback(finaleName);
            }
            else{
                callback(input.replace(/\n/g, " ").replace(/[^A-Z0-9 ]/g, ""));
            }
            
        }
        console.log('22=', temp_Name.charAt(0), temp_Name.split(" ")[0]   );
        if(temp_Name.charAt(0).length == 1 && temp_Name.split(" ")[0].length == 1){
            console.log('37=', temp_Name);
            callback(temp_Name.substring(1).trim());
        }
        else{
            console.log('41', temp_Name.trim() );
            callback(temp_Name.trim());
        }

        
        
    } catch (error) {

    }
}

exports.fetchDateOfFirstRegistation = function (input, callback) {
    try {
        callback(input.replace(/\n/g, " ").replace(/[^0-9 ]/g, ""));
    } catch (error) {

    }
}

exports.fetchAddress = function (input, callback) {
    try {
        let address_final = input.replace(/\n/g, " ").replace("/[^a-zA-Z0-9/ ]/g", "").trim();
        address_final_list = address_final.split(" ");
        let last_word = address_final_list[address_final_list.length -1];
        let last_word_clean = last_word.replace(/O/g, '0');
        // console.log(address_final_list.slice(0, -1).toString(), last_word_clean )
        let addr_part_1 = address_final_list.slice(0, -1).toString();
        let commaFreePArt_one = addr_part_1.replace(/,/g, ' ');
        // console.log('148=', commaFreePArt_one + commaFreePArt_one);
        // let final_address = address_final_list[address_final_list.length -1].toString() + " " + last_word_clean;
        callback(commaFreePArt_one + " " + last_word_clean);
        
    } catch (error) {

    }
}

exports.fetchVinNumber = function (input, callback) {
    try {
        let vin_no_final = "";
        let vinNo = input.replace(/\n/g, " ").replace(/[^a-zA-Z0-9]/g, "");
        console.log('vinNo', vinNo.replace(/O/g, '0'));
        callback( vinNo.replace(/O/g, '0'));
    } catch (error) {

    }
}

exports.findVinNumberFromFreeText = function(input, callback){
    try {
        let list_words = input.split('\n');
        let vinNumber = "";
        let counter = 0;
        let response = {};
        for (i =0; i<list_words.length; i++){
            if(list_words[i].trim().length == 17 && list_words[i].trim().startsWith('SA')){
                console.log('69=', list_words[i].trim());
                vinNumber = list_words[i].trim();
                response.status = 'SUCCESS';
                response.data = vinNumber.replace(/O/g, '0');
                callback(response);
                break;
            }
            counter = counter + 1;
        }
        if(counter == list_words.length){
            response.status = 'ERROR';
            callback(response);
        }
    } catch (error) {
        
    }
}

exports.fetchFirstDORFromFullText = function(input, callback){
    console.log('196=');
    let cleanTextxlists = input.split('\n');
    let dateStr = "";
    for(i=0; i< cleanTextxlists.length; i++){
        console.log('cleanTextxlists[202', cleanTextxlists[i]);
        let cleanLine = cleanTextxlists[i].replace(/ /g, '').trim();
        if(cleanLine.length == 8 && /^\d+$/.test(cleanLine)){
            dateStr = cleanLine;
            break;
            
        }    
    }
    callback(dateStr);
    // callback(dateStr);
}



