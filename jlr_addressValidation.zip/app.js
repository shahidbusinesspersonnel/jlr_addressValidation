//Requiring system dependencies
var path = require('path');
let express = require('express');
let router = require('router');
const cors = require('cors');
const http = require('http');
const https = require('https');
const bodyParser = require('body-parser');
var appConfig = require(path.join(__dirname, 'app', 'configs', 'appConfig'));
const loggermod = require('logger');
http.globalAgent.maxSockets = Infinity;
https.globalAgent.maxSockets = Infinity;
global.middleware  =require(path.join(__dirname, 'app','middlewares','uploadMiddleware'));


let app = express();
let route = router();
let logger = loggermod.createLogger();


app.use('/', express.static(__dirname));
app.use(cors());

app.use(bodyParser({ limit: '100mb' }));
app.use(bodyParser.urlencoded({ extended: true }));

app.use(bodyParser.json({limit: '100mb'}));
//app.use(bodyParser.urlencoded({limit: '100mb', extended: true, parameterLimit: 1000000}));

//app.use(bodyParser.json());
app.use(route);

app.pushResponseToClients = function (request, response, result, isHTML) {
	if (response === undefined)
		return;

	if (isHTML === undefined || isHTML === null) {
		let resultStr = "";
		if (typeof result !== 'undefined' && result !== null)
			resultStr = JSON.stringify(result);

		response.writeHead(200, {
			"Content-Type": "application/json"
		});
		if (request.query && request.query.callback !== undefined && request.query.callback !== null && request.query.callback !== '') {
			logger.debug("Response in query: " + request.query.callback + "('" + resultStr + "')");
			response.write(request.query.callback + "('" + resultStr + "')");
		} else {
			logger.debug("Response in query: " + resultStr);
			response.write(resultStr);
		}
	} else {
		response.writeHead(200, {
			"Content-Type": "text/html"
		});
		response.write(result);
	}
	response.end();
};

require(path.join(__dirname, 'app', 'routes','jlr_routers'))(app, middleware);
// require('./routes/routers.js')(app, middleware);

route.use(function (req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header('Access-Control-Allow-Methods', 'GET,POST');
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	res.header('Access-Control-Allow-Credentials', true);
	next();
});

app.listen(appConfig.port, function () {
	console.log('Nodejs Server is listining on Port:', appConfig.port)
});
module.exports = app;
