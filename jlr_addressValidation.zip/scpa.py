import cv2
import numpy as np
import os
# import pytesseract
from PIL import Image
# import matplotlib.pyplot as plt
# import csv
# import pandas as pd
poppler_path = "C:\\SHAHID_WORK\\poppler-21.09.0\\Library\\bin"
folder = 'scpa_docs/'
from_path = 'scpa_docs\\_from'
to_path = 'scpa_docs\\_to'

from pdf2image import convert_from_path
from pdf2image.exceptions import (
    PDFInfoNotInstalledError,
    PDFPageCountError,
    PDFSyntaxError)


def sort_contours(cnts, method="left-to-right"):
    reverse = False
    i = 0
    if method == "right-to-left" or method == "bottom-to-top":
        reverse = True
    if method == "top-to-bottom" or method == "bottom-to-top":
        i = 1
    boundingBoxes = [cv2.boundingRect(c) for c in cnts]
    (cnts, boundingBoxes) = zip(*sorted(zip(cnts, boundingBoxes),
                                        key=lambda b: b[1][i], reverse=reverse))
    return (cnts, boundingBoxes)


def grayImage(img):
    img0 = cv2.cvtColor(img, cv2.IMREAD_GRAYSCALE)
    dstimg = cv2.cvtColor(img0, cv2.COLOR_BGR2GRAY)
    return dstimg


def get_table(img):
    thresh, img_bin = cv2.threshold(
        img, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

    img_bin = 255-img_bin
    # cv2.imwrite('_to/cv_inverted.png',img_bin)

    # plotting = plt.imshow(img_bin,cmap='gray')
    # plt.show()

    kernel_len = np.array(img).shape[1]//100
    ver_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, kernel_len))
    hor_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_len, 1))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))

    image_1 = cv2.erode(img_bin, ver_kernel, iterations=3)
    vertical_lines = cv2.dilate(image_1, ver_kernel, iterations=3)
    # cv2.imwrite("_to/vertical.jpg", vertical_lines)

    # plotting = plt.imshow(image_1,cmap='gray')
    # plt.show()

    image_2 = cv2.erode(img_bin, hor_kernel, iterations=3)
    horizontal_lines = cv2.dilate(image_2, hor_kernel, iterations=3)
    # cv2.imwrite("_to/horizontal.jpg", horizontal_lines)

    # plotting = plt.imshow(image_2,cmap='gray')
    # plt.show()

    # img_vh = cv2.addWeighted(vertical_lines, 0.5, horizontal_lines, 0.5, 0.0)
    img_vh = cv2.add(vertical_lines, horizontal_lines)

    img_vh = cv2.erode(~img_vh, kernel, iterations=2)
    thresh, img_vh = cv2.threshold(
        img_vh, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    # cv2.imwrite("_to/img_vh.jpg", img_vh)
    bitxor = cv2.bitwise_xor(img, img_vh)
    bitnot = cv2.bitwise_not(bitxor)

    # plotting = plt.imshow(img_vh,cmap='gray')
    # plt.show()
    return img_vh

def select_tablecontours(img_vh, img):
    selected = []
    image = None

    # contours, hierarchy = cv2.findContours(img_vh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours, hierarchy = cv2.findContours(
        img_vh, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    contours, boundingBoxes = sort_contours(contours, method="top-to-bottom")

    box = []
    for c in contours:
        x, y, w, h = cv2.boundingRect(c)
        if (w > 50 and w < 2000 and h > 20 and h < 1000):
            image = cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)
            box.append([x, y, w, h])
            selected.append(c)

    # cv2.imwrite("_to/highlightedTable.png", image)
    # plotting = plt.imshow(image,cmap='gray')
    # plt.show()
    print('selected', selected)
    return image, selected, box


def extract_tablecolumns(img, selected, box):
    heights = [box[i][3] for i in range(len(box)) if box[i][3] > 15]
    mean = np.mean(heights)
    print('mean height', mean)

    cnts_s = np.concatenate(selected)
    x, y, w, h = cv2.boundingRect(cnts_s)
    print(x, y, w, h)

    image_tbl = img[y:y+h, x:x+w]
    # cv2.imwrite("_to/image_tbl.png", image_tbl)
    # cv2.imshow('Table', image_tbl)
    # cv2.waitKey()

    th2, imgt_bin = cv2.threshold(
        image_tbl, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    imgt_bin = 255-imgt_bin

    kernel_len = np.array(img).shape[1]//100
    ver_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, kernel_len))
    image_TV = cv2.erode(imgt_bin, ver_kernel, iterations=3)
    # vertical_tbllines = cv2.dilate(image_TV, ver_kernel, iterations=3)
    # cv2.imwrite("_to/verticalT.jpg", vertical_tbllines)

    # plotting = plt.imshow(image_TV,cmap='gray')
    # plt.show()
    return image_TV, image_tbl


def hconcatImages(imgs, name):
    max_height = 0
    total_width = 0
    images = []
    for image in imgs:
        images.append(image)
        if images[-1].shape[0] > max_height:
            max_height = images[-1].shape[0]
        total_width += images[-1].shape[1]

    final_image = np.zeros((max_height, total_width), dtype=np.uint8)

    current_x = 0
    for image in images:
        final_image[:image.shape[0],
                    current_x:image.shape[1]+current_x] = image
        current_x += image.shape[1]

    # cv2.imwrite(name, final_image)
    return final_image


def create_slices(image_TV, image_tbl):
    # Count pixels along the y-axis, find peaks
    thr_y = 200
    y_sum = np.count_nonzero(image_TV, axis=0)
    peaks = np.where(y_sum > thr_y)[0]

    # Clean peaks
    thr_x = 50
    temp = np.diff(peaks).squeeze()
    idx = np.where(temp > thr_x)[0]
    peaks = np.concatenate(([0], peaks[idx+1]), axis=0) + 1

    # Save sub-images
    slices = []
    head = None
    for i in np.arange(peaks.shape[0] - 1):
        if i == 0:
            head = image_tbl[:, peaks[i]:peaks[i+1]]
        else:
            imgs = [head, image_tbl[:, peaks[i]:peaks[i+1]]]
            final_image = hconcatImages(
                imgs, '_to/sub_image_' + str(i) + '.png')
            # cv2.imwrite('sub_image_' + str(i) + '.png', image_tbl[:, peaks[i]:peaks[i+1]])
            slices.append(final_image)
    return slices

# Process Document


def process_doc(from_path, to_path, image_file):
    print(image_file + ': Reading document into image file..')

    if image_file.endswith('pdf'):
        fname = image_file.split('.')[0]
        list_im = convert_from_path(os.path.join(from_path, image_file),
                                    poppler_path=poppler_path, dpi=300, size=(3300, None))
        i = 0
        ac_list = []
        for im in list_im:
            nfrm = np.array(im)
            if i == 1:
                print('Processing page ' + str(i))
                ###### PREPROCESSING START ######
                grayIm = grayImage(nfrm)
                tblimg = get_table(grayIm)
                # display(Image.fromarray(tblimg))
                # print('tblimg',tblimg)
                image, selected, box = select_tablecontours(tblimg, grayIm)
                image_TV, image_tbl = extract_tablecolumns(
                    image, selected, box)
                # display(Image.fromarray(image_TV))
                slices = create_slices(image_TV, image_tbl)
                ###### PREPROCESSING END ######

                for slc in slices:
                    tmp = 255 * np.ones(nfrm.shape[:2], dtype=np.uint8)
                    text = 'Commercial Pricing and Programme Terms'
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    color = (0, 0, 0)
                    org = (100, 100)
                    cv2.putText(tmp, text, org, font, 1, color, 2, cv2.LINE_AA)
                    ht, wd = slc.shape[:2]
                    tmp[150:150+ht, 100:100+wd] = slc
                    pil_imh = Image.fromarray(tmp)
                    ac_list.append(pil_imh)

            elif i == 0:
                ac_list.append(Image.fromarray(nfrm))

            else:
                print(image_file + ': frame not considered for preprocessing.')
                continue

            i = i+1

        ac_list[0].save(os.path.join(to_path, image_file), save_all=True,
                        append_images=ac_list[1:], resolution=300)

        print(fname + ': processed successfully!')

    else:
        print('Document is not a PDF..')


# poppler_path = "C:\\Users\\1554896\\Documents\\projects\\Binaries\\poppler-21.03.0\\Library\\bin"




def process_documents(from_path, to_path):
    image_files = os.listdir(from_path)
    for image_file in image_files:
        if image_file == "Thumbs.db":
            print('Thumbs.db file. processing ignored.')
        else:
            process_doc(from_path, to_path, image_file)
    print('ALL FILES PROCESSING COMPLETE!')

if __name__ == "__main__":
    process_documents(from_path, to_path)
