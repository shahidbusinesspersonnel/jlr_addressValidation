import cv2
import sys
import numpy as np
# import json
from PIL import Image

# plu

def checkOrientation(ImageBaseDir, imageFileName, image):
    height, width = image.shape[:2]
    if height < width:
        im = Image.open(ImageBaseDir + imageFileName)
        out = im.rotate(270, expand=True)
        out.save(ImageBaseDir + 'rotated_' + imageFileName)
        # image = cv2.rotate(image, cv2.cv2.ROTATE_90_COUNTERCLOCKWISE)
        # cv2.imwrite(ImageBaseDir + 'rotated_' + imageFileName, image)
        return True
    else:
        return False

def process_image_for_ocr(ImageBaseDir, imageFileName):
    image = None
    image = cv2.imread(ImageBaseDir + imageFileName)
    orientationChangesNeeded = checkOrientation(ImageBaseDir, imageFileName, image)
    if orientationChangesNeeded == True:
        image = cv2.imread(ImageBaseDir + 'rotated_' + imageFileName)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.bitwise_not(gray)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.bitwise_not(gray)
    thresh = cv2.threshold(gray, 0, 255,
	cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    coords = np.column_stack(np.where(thresh > 0))
    angle = cv2.minAreaRect(coords)[-1]
    if angle < -45:
	    angle = -(90 + angle)
    else:
	    angle = -angle
    (h, w) = image.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    rotated = cv2.warpAffine(image, M, (w, h),
        flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    
    resized_image = cv2.resize(rotated, (1366, 1821))
    return resized_image


    


if __name__ == "__main__":
    image_url , env = sys.argv[1] , sys.argv[2]
    ImageBaseDir = ""
    if(env == "DEV"):
        ImageBaseDir = 'uploads/'  
    else:
        ImageBaseDir = '/home/ubuntu/jlr/uploads'
    # image_url = 'image_1631474290053.jpg'
    ocrreadIage = process_image_for_ocr(ImageBaseDir, image_url)
    cv2.imwrite(ImageBaseDir + 'OCRREADY_' + image_url, ocrreadIage)
    # print(json.dumps(ImageBaseDir + 'OCRREADY_' + image_url))
    