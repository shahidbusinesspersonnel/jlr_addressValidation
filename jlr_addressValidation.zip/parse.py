import _json

if __name__ == "__main__":
    # input = sys.argv[1]
    input = [{"Delarant_ID" : "G8759894254003", "Decln_UCR": "9GB927153228000-DSVBHX1909001","Customs_Values": "0.00", "Result":"true", "File_Path":"" }]
    print(json_input)